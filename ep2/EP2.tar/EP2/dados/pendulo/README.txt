Comprimento da corda: 50 cm
Ângulo inicial: 10º

Os dados estão no seguinte formato:
[x: número de oscilações] [t: tempo em segundos] [v: velocidade em rad/s]

Obs. As marcações são feitas no ponto onde a velocidade é máxima, e sempre no mesmo sentido (orientação positiva).

