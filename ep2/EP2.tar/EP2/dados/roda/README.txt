Raio da roda: 26 cm
Circunferência da roda: 1,63 m

Os dados estão no seguinte formato:
[x: voltas completadas] [t: tempo em segundos] [v: velocidade em rad/s] [a: aceleração em g]

Obs. O ponto inicial é sempre o ponto mais baixo da roda.

Instantes de parada:
exp1: 72.413
exp2: 192.051
exp3: 262.460
exp4: 395.463
exp5: 449.192
exp6: 516.951

