/*******************************************************************
 * Nome:    Artur Alvarez - 9292931
 *          Mateus Anjos - 9298191
 *          Nícolas Nogueira - 9277541
 *          Victor Domiciano - 8641963
 *
 ******************************************************************/

Para compilar o EP2 é necessário compilar os arquivos StdDraw.java (
cuida da geração de imagens) StdIn.java (leitura de dados de um arquivo) e Pendulo.java (arquivo que implementa o movimento do pêndulo).

javac StdIn.java StdDraw.java Pendulo.java

E para executar:

java Pendulo < exp1.csv