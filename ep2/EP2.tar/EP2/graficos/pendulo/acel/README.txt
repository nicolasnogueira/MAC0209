Os gráficos do acelerômetro possuem uma variação muito pequena (da ordem de 0,02 g).
Por isso, não conseguimos adquirir dados confiáveis/expressivos para análises estatísticas e simulações.

